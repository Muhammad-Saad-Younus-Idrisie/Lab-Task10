#include <stdio.h>
#include <string.h>

#define N 10
#define LEN 50

int main(void) {
    char names[N][LEN];
    char temp[LEN];

    printf("Enter %d student names:\n", N);
    for (int i = 0; i < N; i++) {
        printf("Name %d: ", i + 1);
        fgets(names[i], LEN, stdin);
        names[i][strcspn(names[i], "\n")] = '\0';
    }

    /* Bubble sort: compare adjacent names with strcmp, swap with strcpy */
    for (int i = 0; i < N - 1; i++) {
        for (int j = 0; j < N - 1 - i; j++) {
            if (strcmp(names[j], names[j + 1]) > 0) {
                strcpy(temp, names[j]);
                strcpy(names[j], names[j + 1]);
                strcpy(names[j + 1], temp);
            }
        }
    }

    printf("\nSorted student roster (A to Z):\n");
    for (int i = 0; i < N; i++)
        printf("%2d. %s\n", i + 1, names[i]);

    return 0;
}
