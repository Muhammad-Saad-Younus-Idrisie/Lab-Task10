#include <stdio.h>
#include <string.h>

int main(void) {
    char username[50], password[50];
    char fileUser[50], filePass[50];
    FILE *fptr;

    printf("Enter Username: ");
    scanf("%49s", username);
    printf("Enter Password: ");
    scanf("%49s", password);

    fptr = fopen("credentials.txt", "r");
    if (fptr == NULL) {
        printf("Error: credentials.txt not found!\n");
        return 1;
    }

    /* File format: username and password separated by whitespace */
    fscanf(fptr, "%49s %49s", fileUser, filePass);
    fclose(fptr);

    if (strcmp(username, fileUser) == 0 && strcmp(password, filePass) == 0)
        printf("Access Granted!\n");
    else
        printf("Access Denied!\n");

    return 0;
}
