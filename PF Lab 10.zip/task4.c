#include <stdio.h>

int main(void) {
    char name[50];
    int accountNo;
    float amount;
    FILE *fptr;

    printf("Enter Customer Name: ");
    scanf(" %49[^\n]", name);       /* allows spaces in the name */

    printf("Enter Account Number: ");
    scanf("%d", &accountNo);

    printf("Enter Withdrawal Amount: ");
    scanf("%f", &amount);

    fptr = fopen("bank_log.txt", "a");   /* append mode */
    if (fptr == NULL) {
        printf("Error: Could not open bank_log.txt\n");
        return 1;
    }

    fprintf(fptr, "Name: %s | Account No: %d | Withdrawal: %.2f\n",
            name, accountNo, amount);
    fclose(fptr);

    printf("Transaction logged successfully.\n");
    return 0;
}
