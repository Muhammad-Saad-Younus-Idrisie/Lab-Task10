#include <stdio.h>
#include <string.h>

#define MAX 100

int main(void) {
    char email[MAX];
    char domain[MAX];

    printf("Enter employee email address: ");
    if (fgets(email, sizeof(email), stdin) == NULL) {
        printf("No input received.\n");
        return 1;
    }
    email[strcspn(email, "\n")] = '\0';

    char *at = strchr(email, '@');

    if (at == NULL) {
        printf("Invalid Email Format\n");
    } else {
        strcpy(domain, at + 1);   /* everything after '@' */
        printf("Extracted domain: %s\n", domain);
    }

    return 0;
}
