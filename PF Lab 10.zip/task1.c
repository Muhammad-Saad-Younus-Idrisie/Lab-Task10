#include <stdio.h>
#include <string.h>

#define MAX 500

int main(void) {
    char feedback[MAX];
    char updated[MAX * 2] = "";

    printf("Enter customer feedback: ");
    if (fgets(feedback, sizeof(feedback), stdin) == NULL) {
        printf("No input received.\n");
        return 1;
    }
    feedback[strcspn(feedback, "\n")] = '\0';   /* remove trailing newline */

    printf("Total characters in feedback: %zu\n", strlen(feedback));

    /* Sentiment report */
    int hasGood = (strstr(feedback, "good") != NULL);
    int hasBad  = (strstr(feedback, "bad")  != NULL);

    printf("\n--- Sentiment Report ---\n");
    if (hasGood && hasBad)
        printf("Mixed sentiment: both \"good\" and \"bad\" found.\n");
    else if (hasGood)
        printf("Positive sentiment: \"good\" found.\n");
    else if (hasBad)
        printf("Negative sentiment: \"bad\" found.\n");
    else
        printf("Neutral sentiment: no keywords found.\n");

    /* Replace every "bad" with "not good" */
    if (hasBad) {
        char *rest = feedback;
        char *pos;

        while ((pos = strstr(rest, "bad")) != NULL) {
            strncat(updated, rest, pos - rest);   /* text before "bad" */
            strcat(updated, "not good");          /* replacement       */
            rest = pos + strlen("bad");           /* continue after it */
        }
        strcat(updated, rest);                    /* remaining text    */

        strcpy(feedback, updated);                /* store sanitized review */
        printf("\nUpdated review: %s\n", feedback);
    }

    return 0;
}
